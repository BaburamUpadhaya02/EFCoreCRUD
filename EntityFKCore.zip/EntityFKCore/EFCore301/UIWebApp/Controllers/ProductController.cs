﻿using DAL;
using Microsoft.AspNetCore.Mvc;
using UIWebApp.Models;

namespace UIWebApp.Controllers
{
    public class ProductController : Controller
    {
        //declaring AppDbContext variable
        AppDbContext _db;
        public ProductController()
        {
            //creating AppDbContext object
            _db = new AppDbContext();
        }
        public IActionResult Index()
        {
            var data = _db.Products.ToList();
            return View(data);
            //return View();
        }
        public IActionResult Create()
        {
            ViewBag.CategoryList = _db.Categories;
            return View();
        }
        [HttpPost]
        public IActionResult Create(ProductViewModel model)
        {
            ModelState.Remove("ProductId");
            //ModelState.Remove("Description");
            if (ModelState.IsValid)
            {
                Product product = new Product
                {
                    Name = model.Name,
                    Description = model.Description,
                    UnitPrice = model.UnitPrice,
                    CategoryId = model.CategoryId,
                };
                _db.Products.Add(product);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = _db.Categories;
            return View();
        }
        public IActionResult Edit(int id)//for making get request
        {
            var product = _db.Products.Find(id);
            ViewBag.CategoryList = _db.Categories;
            ProductViewModel productViewModel = new ProductViewModel
            {
                CategoryId = product.CategoryId,
                Name = product.Name,
                ProductId = product.ProductId,
                Description = product.Description,
                UnitPrice = product.UnitPrice,
            };
            return View("Create",productViewModel);
        }
        [HttpPost]
        public IActionResult Edit(ProductViewModel model)
        {
            ModelState.Remove("ProductId");
            //ModelState.Remove("Description");
            if (ModelState.IsValid)
            {
                Product product = new Product
                {
                    ProductId = model.ProductId,
                    Name = model.Name,
                    Description = model.Description,
                    UnitPrice = model.UnitPrice,
                    CategoryId = model.CategoryId,
                };
                _db.Products.Update(product);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = _db.Categories;
            return View("Create", model);
        }
        public IActionResult Delete(int id)
        {
            Product product = _db.Products.Find(id);
            if(product== null)
            {
                _db.Products.Remove(product);
                _db.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
